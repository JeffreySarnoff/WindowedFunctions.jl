* Create a PR to the `dev` branch
* Don't pull in any external dependencies
* Describe what you're solving, or how you had to adapt libmorton to your use case and how the changes are beneficial to the general case
* Thank you! 
